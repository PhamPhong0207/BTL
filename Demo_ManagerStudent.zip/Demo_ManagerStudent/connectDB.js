const { Sequelize } = require("sequelize");

var sequelize = new Sequelize('School','root', 'Abcd@123', {
    host: 'localhost',
    dialect: 'mysql',
});

module.exports = sequelize;