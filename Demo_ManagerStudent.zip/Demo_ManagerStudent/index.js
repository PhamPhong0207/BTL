const sequelize = require('./connectDB');
const express = require('express');
const   cors = require('cors');

// const { where } = require('sequelize');
const readline = require('readline-sync');
// const { mapFinderOptions } = require('sequelize/types/utils');


const { insertData,deleteData } = require('./src/service/product_service');
const Main = require('./src/router/menu');
const router = require('./src/router/router');

sequelize.authenticate()
    .then(() => {
        console.log("success");
        //báo kết nối DB thành công
    })
    .catch((err) => {
        console.log(err); 
        // báo lỗi
    })

const app = express();
app.use(cors())
var bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
const Port = 3000;
app.listen(Port) 
// Main(4); 
app.use(router)






 