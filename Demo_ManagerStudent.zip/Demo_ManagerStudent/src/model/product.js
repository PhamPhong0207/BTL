const { Sequelize } = require("sequelize");


var Project= sequelize.define('Student',{
    id:{
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    name : Sequelize.STRING,
    color: Sequelize.STRING,
    price: Sequelize.DECIMAL(10.1)

},
   {
    timestamps: false
   }
   
);
module.exports=Project