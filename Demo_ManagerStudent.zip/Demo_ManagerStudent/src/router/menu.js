
// const readline = require('readline-sync');
// const { where } = require('sequelize');
// const {insertData,getData,updateData,deleteData}=require('../service/product_service')

// async function Main(a){
    
//     console.log("1.insert data");
//     console.log("2.update data");
//     console.log("3.delete data");
//     console.log("4.insert data");
//     console.log("5.insert data");

 
//     switch(a){
//         case 1:
//              console.log(await getData());
//             break;
//         case 2:
//             await insertData('iphone 11',12000,'blue');
//             break;
//         case 3:
//             await updateData(5,'Phong',20000,'blue');
//             break;
//         case 4:
//             await deleteData(9);
//             break;
        
//     }


// }
// module.exports=Main

