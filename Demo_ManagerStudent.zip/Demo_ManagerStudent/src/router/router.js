
// var Router =require('router');
// var router = Router()
// const { getData, updateData, insertData, deleteData } = require('../service/product_service');

// get ,post, put, delete 
// get('/abc', function (req, res) {
//     // request, response
//     res.send("oke")
// })

// get('/get-list-product', async function (req, res) {
//     const data = await getData()
//     const listProduct = JSON.stringify(data, null, 2)
//     res.send(listStudent)
// })


// post('/add-data-student',async function(req,res){
    
//     console.log("input infor student:")
//     console.log(req.body)
//     const {Name,Age,Class_id}=req.body
//     const data=insertData(Name,Age,Class_id)
//     const listStudent=JSON.stringify(data, null, 2)
//     res.send(listStudent)
// })


// router.put('/update/:id', async function (req,res)  {
//     console.log(req.body)
//     const {id,name,price,color}=req.body
//     console.log(req.params)
//     await updateData(req.params.id,req.body.name,req.body.price,req.body.color)
//     res.send()
// })

// router.delete('/delete/:id', async function(req,res){
//     console.log(req.params.id);
//     await deleteData(req.params.id);
    
//     res.send();

    
// })


// module.exports = router
const express = require('express');
const Routes = express.Router()
// get ,post, put, delete 
Routes.get('/insert-student', async function (req,res) {
})
module.exports = Routes