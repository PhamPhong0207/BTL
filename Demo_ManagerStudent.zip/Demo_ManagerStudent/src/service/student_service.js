const { where } = require("sequelize");
const student = require("../../models/student");


var getData= async(Name,Age,Class_id)=>{
    return await student.findAll();

}
var insertData= async(Name,Age,Class_id)=>{
    return await student.create({Name:Name,Age:Age,Class_id:Class_id})
}
      
var deleteData=async(id)=>{
    return await student.destroy({where:{id:id}})
}

var updateData=async(id,name,price,color)=>{
    return await Project.update({ 
        name,price,color
    },{
    where:{id:id}}
    )
}
module.exports ={
    getData:getData,
    insertData:insertData,
    deleteData:deleteData,
    updateData:updateData
}
